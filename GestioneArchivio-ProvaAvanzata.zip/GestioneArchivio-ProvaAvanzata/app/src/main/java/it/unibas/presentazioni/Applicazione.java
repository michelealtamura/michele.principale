package it.unibas.presentazioni;

import it.unibas.presentazioni.controllo.ControlloDettagli;
import it.unibas.presentazioni.controllo.ControlloMenu;
import it.unibas.presentazioni.controllo.ControlloPrincipale;
import it.unibas.presentazioni.modello.Modello;
import it.unibas.presentazioni.vista.Frame;
import it.unibas.presentazioni.vista.VistaPresentazioni;
import it.unibas.presentazioni.vista.VistaPrincipale;
import it.unibas.presentazioni.vista.VistaSlide;
import javax.swing.SwingUtilities;
import lombok.Getter;

@Getter
public class Applicazione {

    private static final Applicazione singleton = new Applicazione();

    private Applicazione() {
    }
    
    public static Applicazione getInstance() {
        return singleton;
    }
    
    public void inizializza() {
        frame = new Frame();
        vistaPrincipale = new VistaPrincipale();
        vistaPresentazioni = new VistaPresentazioni(frame);
        vistaSlide = new VistaSlide(frame);
        vistaSlide.inizializza();
        vistaPresentazioni.inizializza();
        vistaPrincipale.inizializza();
        frame.inizializza();
    }
    
    Modello modello = new Modello();
    ControlloMenu controlloMenu = new ControlloMenu();
    ControlloPrincipale controlloPrincipale = new ControlloPrincipale();
    ControlloDettagli controlloDettagli = new ControlloDettagli();
    Frame frame;
    VistaPrincipale vistaPrincipale;
    VistaPresentazioni vistaPresentazioni;
    VistaSlide vistaSlide;
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Applicazione.getInstance().inizializza();
            }
        });
    }

}
