package it.unibas.presentazioni.controllo;

import it.unibas.presentazioni.Applicazione;
import it.unibas.presentazioni.modello.EBean;
import it.unibas.presentazioni.modello.Presentazione;
import java.awt.event.ActionEvent;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import lombok.Getter;

@Getter
public class ControlloDettagli {
    
    private Action azioneMostraSlide = new AzioneMostraSlide();
    
    class AzioneMostraSlide extends AbstractAction {

        public AzioneMostraSlide() {
            this.putValue(Action.NAME, "Mostra slide");
            this.putValue(Action.SHORT_DESCRIPTION, "Mostra slide della presentazione");

        }

        @Override
        public void actionPerformed(ActionEvent e) {
            int riga = Applicazione.getInstance().getVistaPresentazioni().getListaPresentazioni().getSelectedIndex();
            if(riga == -1) {
                Applicazione.getInstance().getFrame().mostraMessaggioErrori("Nessuna riga selezionata");
                return;
            }
            List<Presentazione> presentazioni = (List<Presentazione>) Applicazione.getInstance().getModello().getBean(EBean.PRESENTAZIONI_DATA_SCELTA);
            Presentazione presentazioneScelta = presentazioni.get(riga);
            Applicazione.getInstance().getModello().putBean(EBean.PRESENTAZIONE_SELEZIONATA, presentazioneScelta);
            Applicazione.getInstance().getVistaSlide().visualizza();
        }

    }

}
