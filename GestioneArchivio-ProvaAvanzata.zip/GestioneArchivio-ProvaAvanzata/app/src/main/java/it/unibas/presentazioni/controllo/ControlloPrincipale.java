package it.unibas.presentazioni.controllo;

import it.unibas.presentazioni.Applicazione;
import it.unibas.presentazioni.modello.Archivio;
import it.unibas.presentazioni.modello.EBean;
import it.unibas.presentazioni.modello.Presentazione;
import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.tree.TreePath;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Getter
@Slf4j
public class ControlloPrincipale {

    private Action azioneGenera = new AzioneGenera();
    private Action azioneVisualizza = new AzioneVisualizza();

    class AzioneGenera extends AbstractAction {

        public AzioneGenera() {
            this.putValue(Action.NAME, "Genera");
            this.putValue(Action.SHORT_DESCRIPTION, "Genera presentazioni in base al numero indicaato");

        }

        @Override
        public void actionPerformed(ActionEvent e) {
            int numeroPresentazioni = (Integer) Applicazione.getInstance().getVistaPrincipale().getSpinnerPresentazioni().getValue();
            Applicazione.getInstance().getModello().putBean(EBean.NUMERO_PRESENTAZIONI, numeroPresentazioni);
            SwingWorkerGeneraPresentazioni swingWorker = new SwingWorkerGeneraPresentazioni();
            swingWorker.execute();
        }

    }

    class AzioneVisualizza extends AbstractAction {

        public AzioneVisualizza() {
            this.putValue(Action.NAME, "Visualizza");
            this.putValue(Action.SHORT_DESCRIPTION, "Visualizza presentazioni per data");

        }

        @Override
        public void actionPerformed(ActionEvent e) {
            TreePath percorso = Applicazione.getInstance().getVistaPrincipale().getAlberoPresentazioni().getSelectionPath();
            if(percorso == null) {
                Applicazione.getInstance().getFrame().mostraMessaggioErrori("Nessuna data selezionata");
                return;
            }
            Object[] elementi = percorso.getPath();
            if (elementi.length != 4) {
                Applicazione.getInstance().getFrame().mostraMessaggioErrori("Selezionare una data corretta");
                return;
            }
            Archivio archivio = (Archivio) Applicazione.getInstance().getModello().getBean(EBean.ARCHIVIO);
            int anno = Integer.parseInt(elementi[1].toString());
            int mese = Integer.parseInt(elementi[2].toString());
            int giorno = Integer.parseInt(elementi[3].toString());
            List<Presentazione> presentazioniPerData = archivio.cercaPerData(LocalDate.of(anno, mese, giorno));
            Applicazione.getInstance().getModello().putBean(EBean.PRESENTAZIONI_DATA_SCELTA, presentazioniPerData);
            Applicazione.getInstance().getVistaPresentazioni().visualizza();
        }
    }

}
