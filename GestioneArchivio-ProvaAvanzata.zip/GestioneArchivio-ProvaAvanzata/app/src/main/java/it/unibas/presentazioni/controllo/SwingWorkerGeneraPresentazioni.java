package it.unibas.presentazioni.controllo;

import it.unibas.presentazioni.Applicazione;
import it.unibas.presentazioni.modello.Archivio;
import it.unibas.presentazioni.modello.EBean;
import it.unibas.presentazioni.modello.Presentazione;
import it.unibas.presentazioni.modello.DatiAlbero;
import it.unibas.presentazioni.vista.ModelloAlberoPresentazioni;
import javax.swing.SwingWorker;
import javax.swing.tree.DefaultTreeModel;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SwingWorkerGeneraPresentazioni extends SwingWorker<Archivio, Void> {

    @Override
    protected Archivio doInBackground() throws Exception {
        Archivio archivio = new Archivio();
        archivio.caricaPresentazioni((Integer) Applicazione.getInstance().getModello().getBean(EBean.NUMERO_PRESENTAZIONI));
        Thread.sleep(5000);
        return archivio;
    }

    @Override
    protected void done() {
        try {
            Archivio archivio = get();
            Applicazione.getInstance().getModello().putBean(EBean.ARCHIVIO, archivio);
            Applicazione.getInstance().getFrame().mostraMessaggioInformazioni("Archivio caricato correttamente");
            log.debug("Presentazioni create:");
            for (Presentazione presentazione : archivio.getPresentazioni()) {
                log.debug("{}", presentazione);
            }
            DatiAlbero datiAlbero = archivio.calcolaDatiAlbero();
            Applicazione.getInstance().getVistaPrincipale().getAlberoPresentazioni().setModel(new DefaultTreeModel(new ModelloAlberoPresentazioni().costruisciTreeNode(datiAlbero)));
        } catch (Exception e) {
            Applicazione.getInstance().getFrame().mostraMessaggioErrori("Errore nel cricamento dell'archivio");
        }
    }

}
