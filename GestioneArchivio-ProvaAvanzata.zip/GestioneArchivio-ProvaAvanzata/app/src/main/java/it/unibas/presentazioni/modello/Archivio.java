package it.unibas.presentazioni.modello;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import lombok.Getter;

@Getter
public class Archivio {

    private List<Presentazione> presentazioni = new ArrayList<>();

    public void caricaPresentazioni(int numeroDaGenerare) {
        Long epochDayInizio = LocalDate.of(2020, 1, 1).toEpochDay();
        Long epochDayFine = LocalDate.of(2023, 12, 31).toEpochDay();
        Random random = new Random();
        for (int i = 0; i < numeroDaGenerare; i++) {
            Long epochDayRandom = random.nextLong(epochDayInizio, epochDayFine + 1);
            Presentazione nuovaPresentazione = new Presentazione("Presentazione mock n." + i, LocalDate.ofEpochDay(epochDayRandom), "Autore mock n." + i);
            nuovaPresentazione.getSlide().add(new SlideSoloImmagine("nome file mock n." + i, 10, "Slide mock immgine n." + i, 1));
            nuovaPresentazione.getSlide().add(new SlideSoloTesto("testo mock n." + i, "Slide mock testo n." + i, 2));
            nuovaPresentazione.getSlide().add(new SlideVuota( "Colore sfondo", "Slide mock immgine n." + i, 3));
            this.presentazioni.add(nuovaPresentazione);
        }
    }

    public DatiAlbero calcolaDatiAlbero() {
        Set<String> anni = new HashSet<>();
        Map<String, Set<String>> mesiAnni = new HashMap<>();
        Map<String, Set<String>> giorniInMese = new HashMap<>();
        for (Presentazione presentazione : presentazioni) {
            int anno = presentazione.getData().getYear();
            int mese = presentazione.getData().getMonthValue();
            int giorno = presentazione.getData().getDayOfMonth();
            
            anni.add("" + anno);
            
            Set<String> stringheAnni = mesiAnni.get("" + anno);
            if(stringheAnni == null) {
                stringheAnni = new HashSet<>();
                mesiAnni.put("" + anno, stringheAnni);
            }
            stringheAnni.add("" + mese);
            
            Set<String> stringheGiorni = giorniInMese.get(anno + "-" + mese);
            if(stringheGiorni == null) {
                stringheGiorni = new HashSet<>();
                giorniInMese.put(anno + "-" + mese, stringheGiorni);
            }
            stringheGiorni.add("" + giorno);           
        }
        return new DatiAlbero(anni, mesiAnni, giorniInMese);
    }
    
    public List<Presentazione> cercaPerData(LocalDate data) {
        List<Presentazione> presentazioniPerData = new ArrayList<>();
        for (Presentazione presentazione : presentazioni) {
            if(presentazione.getData().equals(data)) {
                presentazioniPerData.add(presentazione);
            }        
        }
        return presentazioniPerData;
    }
}
