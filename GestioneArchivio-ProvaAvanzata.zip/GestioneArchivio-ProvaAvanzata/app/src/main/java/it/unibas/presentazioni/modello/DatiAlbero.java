package it.unibas.presentazioni.modello;

import java.util.Map;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@AllArgsConstructor
@ToString
@Getter
public class DatiAlbero{
    
    private Set<String> anni;
    private Map<String, Set<String>> mesiAnni;
    private Map<String, Set<String>> giorniInMese;

}
