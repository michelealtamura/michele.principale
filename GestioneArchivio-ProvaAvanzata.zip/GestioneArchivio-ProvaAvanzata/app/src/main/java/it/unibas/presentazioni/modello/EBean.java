package it.unibas.presentazioni.modello;

public enum EBean {
    ARCHIVIO,
    NUMERO_PRESENTAZIONI,
    PRESENTAZIONI_DATA_SCELTA,
    PRESENTAZIONE_SELEZIONATA
    
}
