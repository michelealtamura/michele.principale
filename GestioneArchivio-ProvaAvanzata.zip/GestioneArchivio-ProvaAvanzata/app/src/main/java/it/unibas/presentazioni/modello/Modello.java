package it.unibas.presentazioni.modello;

import java.util.HashMap;
import java.util.Map;

public class Modello {
    
    private Map<EBean, Object> beans = new HashMap<>();
    
    public void putBean(EBean chiave, Object bean) {
        this.beans.put(chiave, bean);
    }
    
    public Object getBean(EBean bean) {
        return this.beans.get(bean);
    }

}
