package it.unibas.presentazioni.modello;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@AllArgsConstructor
@ToString
@Getter
public class Presentazione {
    
    private String titolo;
    private LocalDate data;
    private String autore;
    private final List<Slide> slide = new ArrayList<>();

}
