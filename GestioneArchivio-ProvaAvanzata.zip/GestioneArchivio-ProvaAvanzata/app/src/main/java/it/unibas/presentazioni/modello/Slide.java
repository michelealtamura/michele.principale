package it.unibas.presentazioni.modello;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public abstract class Slide {
    
    private String titolo;
    private int numeroPagina;
    
}
