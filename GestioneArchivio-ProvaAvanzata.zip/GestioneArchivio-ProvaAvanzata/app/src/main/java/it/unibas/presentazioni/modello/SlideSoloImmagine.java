package it.unibas.presentazioni.modello;

import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
public class SlideSoloImmagine extends Slide {

    private String nomeFile;
    private int peso;

    public SlideSoloImmagine(String nomeFile, int peso, String titolo, int numeroPagina) {
        super(titolo, numeroPagina);
        this.nomeFile = nomeFile;
        this.peso = peso;
    }

}
