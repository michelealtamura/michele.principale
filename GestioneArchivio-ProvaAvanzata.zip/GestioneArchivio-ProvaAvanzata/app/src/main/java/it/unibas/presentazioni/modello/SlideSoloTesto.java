package it.unibas.presentazioni.modello;

import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
public class SlideSoloTesto extends Slide {

    private String testo;

    public SlideSoloTesto(String testo, String titolo, int numeroPagina) {
        super(titolo, numeroPagina);
        this.testo = testo;
    }

}
