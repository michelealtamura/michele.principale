package it.unibas.presentazioni.modello;

import lombok.Getter;
import lombok.ToString;

@ToString
@Getter
public class SlideVuota extends Slide {
    
    private String coloreSfondo;

    public SlideVuota(String coloreSfondo, String titolo, int numeroPagina) {
        super(titolo, numeroPagina);
        this.coloreSfondo = coloreSfondo;
    }    

}
