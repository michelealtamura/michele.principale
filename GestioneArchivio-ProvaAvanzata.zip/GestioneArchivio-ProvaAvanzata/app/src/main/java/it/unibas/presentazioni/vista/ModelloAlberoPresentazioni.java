package it.unibas.presentazioni.vista;

import it.unibas.presentazioni.modello.DatiAlbero;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;

public class ModelloAlberoPresentazioni {
    
    public TreeNode costruisciTreeNode(DatiAlbero dati) {
        DefaultMutableTreeNode radice = new DefaultMutableTreeNode("Presentazioni");
        for (String anno : dati.getAnni()) {
            DefaultMutableTreeNode nodoAnno = new DefaultMutableTreeNode(anno);
            radice.add(nodoAnno);
            for (String mese : dati.getMesiAnni().get(anno)) {
                DefaultMutableTreeNode nodoMese = new DefaultMutableTreeNode(mese);
                nodoAnno.add(nodoMese);
                for (String giorno : dati.getGiorniInMese().get(anno + "-" + mese)) {
                    DefaultMutableTreeNode nodoGiorno = new DefaultMutableTreeNode(giorno);
                    nodoMese.add(nodoGiorno);
                }
            }
        }
        return radice;
    }

}
