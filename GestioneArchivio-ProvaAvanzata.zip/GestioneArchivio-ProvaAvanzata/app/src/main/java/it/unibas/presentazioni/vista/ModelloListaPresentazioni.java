package it.unibas.presentazioni.vista;

import it.unibas.presentazioni.modello.Presentazione;
import java.util.List;
import javax.swing.AbstractListModel;

public class ModelloListaPresentazioni extends AbstractListModel {
    
    private List<Presentazione> presentazioni;
    
    public ModelloListaPresentazioni(List<Presentazione> presentazioni) {
        this.presentazioni = presentazioni;
    }

    @Override
    public int getSize() {
        return presentazioni.size();
    }

    @Override
    public Object getElementAt(int index) {
        return this.presentazioni.get(index).getTitolo();
    }
    
    public void aggiornaContenuto() {
        super.fireContentsChanged(this, 0, getSize());
    }

}
