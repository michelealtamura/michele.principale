package it.unibas.presentazioni.vista;

import it.unibas.presentazioni.modello.Slide;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class ModelloTabellaSlide extends AbstractTableModel {
    
    private List<Slide> slide;
    
    public ModelloTabellaSlide(List<Slide> slide) {
        this.slide = slide;
    }

    @Override
    public int getRowCount() {
        return slide.size();
    }

    @Override
    public int getColumnCount() {
        return 2;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Slide riga = this.slide.get(rowIndex);
        if(columnIndex == 0) {
            return riga.getNumeroPagina();
        }
        return riga.getTitolo();
    }
    
    @Override
    public String getColumnName(int column) {
        if(column == 0) {
            return "Numero pagina";
        }
        return "Titolo";
    }
    
        public void aggiornaContenuto() {
        super.fireTableDataChanged();
    }

}
