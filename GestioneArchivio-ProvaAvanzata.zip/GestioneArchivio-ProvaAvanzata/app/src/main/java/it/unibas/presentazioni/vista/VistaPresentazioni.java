package it.unibas.presentazioni.vista;

import it.unibas.presentazioni.Applicazione;
import it.unibas.presentazioni.modello.EBean;
import it.unibas.presentazioni.modello.Presentazione;
import java.util.List;
import lombok.Getter;

@Getter
public class VistaPresentazioni extends javax.swing.JDialog {

    public VistaPresentazioni(java.awt.Frame parent) {
        super(parent, true);
    }

    public void inizializza() {
        initComponents();
        this.bottoneDettagliSlide.setAction(Applicazione.getInstance().getControlloDettagli().getAzioneMostraSlide());
    }
    
    public void visualizza() {
        this.listaPresentazioni.setModel(new ModelloListaPresentazioni((List<Presentazione>) Applicazione.getInstance().getModello().getBean(EBean.PRESENTAZIONI_DATA_SCELTA)));
        this.setLocationRelativeTo(Applicazione.getInstance().getFrame());
        this.setVisible(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.JScrollPane jScrollPane1 = new javax.swing.JScrollPane();
        listaPresentazioni = new javax.swing.JList<>();
        bottoneDettagliSlide = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jScrollPane1.setViewportView(listaPresentazioni);

        bottoneDettagliSlide.setText("jButton1");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 444, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(bottoneDettagliSlide)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bottoneDettagliSlide)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bottoneDettagliSlide;
    private javax.swing.JList<String> listaPresentazioni;
    // End of variables declaration//GEN-END:variables
}
