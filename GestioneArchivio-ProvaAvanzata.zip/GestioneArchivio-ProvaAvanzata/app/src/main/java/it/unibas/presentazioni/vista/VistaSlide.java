package it.unibas.presentazioni.vista;

import it.unibas.presentazioni.Applicazione;
import it.unibas.presentazioni.modello.EBean;
import it.unibas.presentazioni.modello.Presentazione;

public class VistaSlide extends javax.swing.JDialog {

    public VistaSlide(java.awt.Frame parent) {
        super(parent, true);
    }

    public void inizializza() {
        initComponents();
    }
    
    public void visualizza() {
        Presentazione presentazioneSelezionata = (Presentazione) Applicazione.getInstance().getModello().getBean(EBean.PRESENTAZIONE_SELEZIONATA);
        this.tabellaSlide.setModel(new ModelloTabellaSlide(presentazioneSelezionata.getSlide()));
        this.setLocationRelativeTo(Applicazione.getInstance().getFrame());
        this.setVisible(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.JScrollPane jScrollPane1 = new javax.swing.JScrollPane();
        tabellaSlide = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        tabellaSlide.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabellaSlide);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 375, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 275, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable tabellaSlide;
    // End of variables declaration//GEN-END:variables
}
