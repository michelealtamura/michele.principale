package it.unibas.presentazioni.test;

import it.unibas.presentazioni.modello.Archivio;
import it.unibas.presentazioni.modello.Presentazione;
import it.unibas.presentazioni.modello.DatiAlbero;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

@Slf4j
public class TestArchivio {

    private Archivio archivio;

    @BeforeEach
    public void setUp() {
        archivio = new Archivio();
    }

    @Test
    public void testGenerazione() {
        archivio.caricaPresentazioni(12);
        Assertions.assertEquals(12, archivio.getPresentazioni().size());
        log.debug("Presentazioni:");
        for (Presentazione presentazione : archivio.getPresentazioni()) {
            log.debug("{}", presentazione);
        }
    }
    
    @Test
    public void testDatiAlbero() {
        archivio.caricaPresentazioni(12);
        DatiAlbero datiAlbero = archivio.calcolaDatiAlbero();
        log.debug(datiAlbero.toString());
    }

}
